SELECT equipmentType 
FROM equipmentType

